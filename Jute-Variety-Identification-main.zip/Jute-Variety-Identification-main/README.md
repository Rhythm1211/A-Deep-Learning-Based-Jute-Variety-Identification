# Jute Fiber Variety Identification Using Deep Learning

This project implements various deep learning models for classifying different varieties of jute fiber using microscopic and smartphone images.

## Dataset

The dataset used in this project is the "Jute Variety Dataset" which contains images of different jute fiber varieties:
- Bangladeshi White
- Indian White
- Mesta

Each variety includes two types of images:
- Microscopic images captured using laboratory microscopes
- Smartphone images captured using mobile devices

### Dataset Structure
```
Jute Variety Dataset/
├── Bangladeshi_White/
│   ├── White_Microscope/
│   └── White_Smartphone/
├── Indian_White/
│   ├── White_Microscope/
│   └── White_Smartphone/
└── Mesta/
    ├── Mesta_Microscope/
    └── Mesta_Smartphone/
```

## Models Implemented

1. EfficientNetV2S
2. ResNet101V2
3. ResNet152V2 (Best Performed)
4. ConvNextBase
5. MobileNetV3-Large

## Key Features

- Data preprocessing and augmentation
- Class weight balancing
- Transfer learning with pretrained models
- Custom metrics implementation
- Model performance visualization
- Confusion matrix analysis

## Performance Metrics

Models were evaluated using:
- Accuracy
- Precision
- Recall
- F1 Score

## Requirements

```
tensorflow
keras
scikit-learn
numpy
matplotlib
plotly
opencv-python
efficientnet
timm
keras-cv
```

## Usage

1. Dataset Preparation:
```python
python prepare_dataset.py
```

2. Model Training:
```python
python train_model.py
```

3. Evaluation:
```python
python evaluate_model.py
```


## Contributing

Feel free to fork this repository and submit pull requests for improvements.

## License

This project is licensed under the MIT License - see the LICENSE file for details.


## Acknowledgments

- Thanks to the contributors of the Jute Variety Dataset
- TensorFlow and PyTorch communities
- All other open-source libraries used in this project
